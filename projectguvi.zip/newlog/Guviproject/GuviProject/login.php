<!DOCTYPE>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Login Form||B2H Creations</title>

<link href="bootstrap/css/bootstrap.css" rel="stylesheet">
<link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" media="screen"> 
<link href="css/style.css" rel="stylesheet" type="text/css" media="screen">
<link href="css/header.css" rel="stylesheet" type="text/css" media="screen">
<link rel="icon" type="icon" href="img/4.svg">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light" style="background-color: #b642f4">
  <a class="navbar-brand" href="#"><img src="img/4.svg" style="width: 100px; margin-left: 20px;"></a>

    <h2>B2H||Creations Log In</h2>
<img src="img/1.jpg" class="rounded float-right" alt="right" style="width:500px; margin-left: 35%;">

  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  
</nav>
   
<div class="signin-form">

	<div class="container">
     
        
       <form class="form-signin" method="post" id="login-form">
      
        <h2 class="form-signin-heading">Login form</h2><hr />
        
        <div id="error">
        <!-- error will be showen here ! -->
        </div>

        <div class="form-group">
        <input type="email" class="form-control" placeholder="Email address" name="user_email" id="user_email" />
        <span id="check-e"></span>
        </div>
        
        <div class="form-group">
        <input type="password" class="form-control" placeholder="Password" name="password" id="password" />
        </div>
        
     	<hr />
        
        <div class="form-group">
            <button type="submit" class="btn btn-info" name="btn-save" id="btn-submit">
    		<span class="glyphicon glyphicon-log-in"></span>  Login
			</button> 
        </div>  
<div class="row">
<div class="col-md-12 col-sm-12 col-xs-12">
<p > Please click <a href="register.php"> Here</a> to register with us.</p>
</div>
</div>      
      </form>
	  
    </div>
    
</div>
<br>

<img src="img/1.jpg" class="rounded mx-auto d-block" alt="..." style="border-radius: 30px;">

 <script type="text/javascript" src="js/jquery-1.11.3-jquery.min.js"></script>
<script type="text/javascript" src="js/validation.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>

</body>
</html>