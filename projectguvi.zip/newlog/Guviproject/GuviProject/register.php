<!DOCTYPE html >
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Sign In for B2H||Creations</title>
<link rel="icon" type="icon" href="img/4.svg">

<link href="bootstrap/css/bootstrap.css" rel="stylesheet">
<link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" media="screen"> 


<link href="css/style.css" rel="stylesheet" type="text/css" media="screen">



</head>

<body>
     <nav class="navbar navbar-expand-lg navbar-light" style="background-color: #9a07b5">
  <a class="navbar-brand" href="#"><img src="img/4.svg" style="width: 100px; margin-left: 20px;"></a>

    <h2>B2H||Creations Signin</h2>
<img src="img/1.jpg" class="rounded float-right" alt="right" style="width:500px; margin-left: 35%;">


  
</nav>

   
<div class="signin-form">

	<div class="container">
     
        
       <form class="form-signin" method="post" id="register-form">
      
        <h2 class="form-signin-heading">Sign Up</h2><hr />
        
        <div id="error">
        <!-- error will be showen here ! -->
        </div>
        
        <div class="form-group">
        <input type="text" class="form-control" placeholder="Enter Your Name" name="name" id="name" />
        </div>
        
        <div class="form-group">
        <input type="email" class="form-control" placeholder="Email address" name="user_email" id="user_email" />
        <span id="check-e"></span>
        </div>

         <div class="form-group">
        <input type="date" class="form-control" placeholder="Date of Brith" name="user_date" id="date_br" />
        <span id="check-e"></span>
        </div>
         <div class="form-group">
        <input type="text" class="form-control" placeholder="Age" name="user_age" id="user_age" />
        <span id="check-e"></span>
        </div>
         <div class="form-group">
        <input type="text" class="form-control" placeholder="Contact" name="user_contact" id="user_contact" />
        <span id="check-e"></span>
        </div>
        
        
        <div class="form-group">
        <input type="password" class="form-control" placeholder="Password" name="password" id="password" />
        </div>
        
        <div class="form-group">
        <input type="password" class="form-control" placeholder="Retype Password" name="cpassword" id="cpassword" />
        </div>
     	<hr />
        
        <div class="form-group">
           <a href="#"><button type="submit" class="btn btn-info" name="btn-save" id="btn-submit">
    		<span class=" glyphicon glyphicon-user"></span> Create Account
			</button> </a>
        </div>  
      
	  <div class="row">
<div class="col-md-12 col-sm-12 col-xs-12">
<p> If you have Register successfully you can please click <a href="login.php"> Here</a></p>
</div>
</div>
      </form>
	  


    </div>
    
</div>
 <script type="text/javascript" src="js/jquery-1.11.3-jquery.min.js"></script>
<script type="text/javascript" src="js/validation.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>

</body>
</html>